import { SpendlyApp } from '@/components/spendly-app'

export default function Page() {
  return <SpendlyApp />
}
