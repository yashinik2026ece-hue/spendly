import { notFound } from 'next/navigation'
import { SpendlyApp } from '@/components/spendly-app'

const pages: Record<string, string> = {
  transactions: 'Transactions',
  budgets: 'Budgets',
  'split-settle': 'Split & Settle',
  subscriptions: 'Subscriptions',
  'savings-garden': 'Savings Garden',
  'smart-insights': 'Smart Insights',
  'no-spend-challenge': 'No-Spend Challenge',
  reports: 'Reports',
  settings: 'Settings',
}

export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) {
  const { section } = await params
  const page = pages[section]
  if (!page) notFound()
  return <SpendlyApp initialPage={page} />
}
