import { TRANSACTION_CATEGORIES, type MonthlyBudget, type Transaction } from './spendly-types'

export const TRANSACTION_STORAGE_KEY = 'spendly_transactions'
export const BUDGET_STORAGE_KEY = 'spendly_budgets'

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function isDate(value: unknown): value is string {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00`))
}

export function isTransaction(value: unknown): value is Transaction {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.description === 'string'
    && value.description.trim().length > 0
    && typeof value.amount === 'number'
    && Number.isFinite(value.amount)
    && value.amount > 0
    && (value.type === 'income' || value.type === 'expense')
    && typeof value.category === 'string'
    && TRANSACTION_CATEGORIES.includes(value.category as (typeof TRANSACTION_CATEGORIES)[number])
    && isDate(value.date)
    && (value.note === undefined || typeof value.note === 'string')
}

export function isMonthlyBudget(value: unknown): value is MonthlyBudget {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.month === 'string'
    && /^\d{4}-(0[1-9]|1[0-2])$/.test(value.month)
    && typeof value.category === 'string'
    && (value.category === 'Overall' || TRANSACTION_CATEGORIES.includes(value.category as (typeof TRANSACTION_CATEGORIES)[number]))
    && typeof value.amount === 'number'
    && Number.isFinite(value.amount)
    && value.amount > 0
}

function readArray<T>(key: string, validate: (item: unknown) => item is T): T[] | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(key)
    if (raw === null) return null
    const parsed: unknown = JSON.parse(raw)
    if (!Array.isArray(parsed) || !parsed.every(validate)) {
      window.localStorage.removeItem(key)
      return []
    }
    return parsed
  } catch {
    try { window.localStorage.removeItem(key) } catch { /* storage may be disabled */ }
    return []
  }
}

function writeArray<T>(key: string, values: T[]): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(key, JSON.stringify(values))
  } catch {
    // Storage can be unavailable or full; in-memory state remains usable.
  }
}

export const spendlyStorage = {
  readTransactions: () => readArray<Transaction>(TRANSACTION_STORAGE_KEY, isTransaction),
  writeTransactions: (transactions: Transaction[]) => writeArray(TRANSACTION_STORAGE_KEY, transactions),
  readBudgets: () => readArray<MonthlyBudget>(BUDGET_STORAGE_KEY, isMonthlyBudget),
  writeBudgets: (budgets: MonthlyBudget[]) => writeArray(BUDGET_STORAGE_KEY, budgets),
  readSavingsGoal: () => {
    if (typeof window === 'undefined') return null
    try {
      const value = Number(window.localStorage.getItem('spendly_savings_goal'))
      return Number.isFinite(value) && value > 0 ? value : null
    } catch { return null }
  },
  writeSavingsGoal: (value: number) => {
    if (typeof window === 'undefined') return
    try { window.localStorage.setItem('spendly_savings_goal', String(value)) } catch { /* Storage can be unavailable or full. */ }
  },
}
