import { calculateTotals, roundMoney } from './spendly-calculations'
import type { FinanceTotals, Transaction } from './spendly-types'

export type SpendingAlert = { category: string; current: number; previous: number; difference: number }
export type WellnessScore = { score: number; net: number; savings: number; budget: number | null; comparison: number | null; coverage: number }

export function calculateSafeToSpend(totals: FinanceTotals, upcomingSubscriptions: number, daysRemaining: number) {
  if (totals.income <= 0) return null
  const available = roundMoney(totals.income - totals.expenses - upcomingSubscriptions)
  return { available: Math.max(0, available), recordedRemainder: available, perDay: roundMoney(Math.max(0, available) / Math.max(1, daysRemaining)) }
}

export function compareMonths(currentTransactions: Transaction[], previousTransactions: Transaction[]) {
  const current = calculateTotals(currentTransactions).expenses
  const previous = calculateTotals(previousTransactions).expenses
  return { current, previous, difference: roundMoney(current - previous), percent: previous > 0 ? Math.round((current - previous) / previous * 100) : null }
}

export function findUnusualCategorySpending(currentTransactions: Transaction[], previousTransactions: Transaction[], minIncrease = 10, minPercent = 50): SpendingAlert[] {
  const totals = (items: Transaction[]) => items.reduce<Record<string, number>>((result, transaction) => {
    if (transaction.type === 'expense') result[transaction.category] = roundMoney((result[transaction.category] ?? 0) + transaction.amount)
    return result
  }, {})
  const current = totals(currentTransactions)
  const previous = totals(previousTransactions)
  return Object.entries(current).flatMap(([category, amount]) => {
    const prior = previous[category] ?? 0
    const difference = roundMoney(amount - prior)
    return prior > 0 && difference >= minIncrease && amount >= prior * (1 + minPercent / 100)
      ? [{ category, current: amount, previous: prior, difference }] : []
  }).sort((a, b) => b.difference - a.difference)
}

export function calculateWellnessScore(currentTransactions: Transaction[], previousTransactions: Transaction[], monthlyBudget: number) : WellnessScore | null {
  const totals = calculateTotals(currentTransactions)
  if (totals.income <= 0 || totals.expenses <= 0) return null
  const net = totals.balance > 0 ? 30 : totals.balance === 0 ? 15 : 0
  const savings = Math.min(25, Math.round(Math.max(0, totals.savingsRate) / 20 * 25))
  const budget = monthlyBudget > 0 ? Math.round(Math.max(0, 20 - Math.max(0, totals.expenses / monthlyBudget - 1) * 20)) : null
  const priorExpenses = calculateTotals(previousTransactions).expenses
  const comparison = previousTransactions.length > 0 ? (totals.expenses <= priorExpenses ? 15 : 0) : null
  const coverage = Math.round(Math.min(1, currentTransactions.length / 4) * 10)
  const availablePoints = 65 + (budget === null ? 0 : 20) + (comparison === null ? 0 : 15)
  const earnedPoints = net + savings + (budget ?? 0) + (comparison ?? 0) + coverage
  return { score: Math.round(earnedPoints / availablePoints * 100), net, savings, budget, comparison, coverage }
}
