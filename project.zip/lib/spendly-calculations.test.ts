import { describe, expect, it } from 'vitest'
import { aggregateMonthlyTotals, calculateBudgetProgress, calculateTotals, getTransactionsForMonth, sumBudgets } from './spendly-calculations'
import type { MonthlyBudget, Transaction } from './spendly-types'

const transactions: Transaction[] = [
  { id: '1', description: 'Allowance', amount: 1000, type: 'income', category: 'Other', date: '2026-11-01' },
  { id: '2', description: 'Groceries', amount: 120, type: 'expense', category: 'Food', date: '2026-11-03' },
  { id: '3', description: 'Books', amount: 80, type: 'expense', category: 'Education', date: '2026-11-05' },
  { id: '4', description: 'Previous month', amount: 40, type: 'expense', category: 'Food', date: '2026-10-30' },
]

describe('Spendly finance calculations', () => {
  it('calculates income, spending, balance, and savings rate from transactions', () => {
    expect(calculateTotals(transactions)).toEqual({ income: 1000, expenses: 240, balance: 760, savingsRate: 76 })
  })

  it('rounds decimal totals to cents', () => {
    const fractional: Transaction[] = [
      { id: 'a', description: 'First', amount: 0.1, type: 'income', category: 'Other', date: '2026-11-01' },
      { id: 'b', description: 'Second', amount: 0.2, type: 'income', category: 'Other', date: '2026-11-02' },
    ]
    expect(calculateTotals(fractional).income).toBe(0.3)
  })

  it('returns a zero savings rate when no income is recorded', () => {
    expect(calculateTotals([{ ...transactions[1], amount: 25 }])).toEqual({ income: 0, expenses: 25, balance: -25, savingsRate: 0 })
  })

  it('filters monthly totals without including other months', () => {
    expect(getTransactionsForMonth(transactions, '2026-11')).toHaveLength(3)
    expect(aggregateMonthlyTotals(transactions, '2026-11')).toEqual({ income: 1000, expenses: 200, balance: 800, savingsRate: 80 })
  })

  it.each([
    [40, null], [50, 50], [75, 75], [90, 90], [100, 100], [125, 100],
  ])('reports correct budget threshold for %s percent usage', (amount, alert) => {
    const budget: MonthlyBudget = { id: 'food', month: '2026-11', category: 'Food', amount: 100 }
    const expense: Transaction = { id: 'e', description: 'Food', amount, type: 'expense', category: 'Food', date: '2026-11-12' }
    expect(calculateBudgetProgress(budget, [expense]).alert).toBe(alert)
  })

  it('does not count income or other categories toward category budgets', () => {
    const budget: MonthlyBudget = { id: 'food', month: '2026-11', category: 'Food', amount: 200 }
    const progress = calculateBudgetProgress(budget, transactions)
    expect(progress.spent).toBe(120)
    expect(progress.remaining).toBe(80)
    expect(progress.percentUsed).toBe(60)
    expect(progress.alert).toBe(50)
  })

  it('prefers a monthly overall budget over the sum of category limits', () => {
    const budgets: MonthlyBudget[] = [
      { id: 'overall', month: '2026-11', category: 'Overall', amount: 500 },
      { id: 'food', month: '2026-11', category: 'Food', amount: 200 },
      { id: 'old', month: '2026-10', category: 'Overall', amount: 900 },
    ]
    expect(sumBudgets(budgets, '2026-11')).toBe(500)
    expect(sumBudgets(budgets.slice(1, 2), '2026-11')).toBe(200)
    expect(sumBudgets([], '2026-11')).toBe(0)
  })
})
