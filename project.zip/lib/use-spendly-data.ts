'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { spendlyStorage } from '@/lib/spendly-storage'
import type { MonthlyBudget, Transaction } from '@/lib/spendly-types'

export function useSpendlyData() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [budgets, setBudgets] = useState<MonthlyBudget[]>([])
  const [savingsGoal, setSavingsGoal] = useState(320)
  const [ready, setReady] = useState(false)
  const skipTransactionWrite = useRef(false)
  const skipBudgetWrite = useRef(false)
  const skipSavingsGoalWrite = useRef(false)

  useEffect(() => {
    const storedTransactions = spendlyStorage.readTransactions()
    const storedBudgets = spendlyStorage.readBudgets()
    const initialTransactions = (storedTransactions ?? []).filter(transaction => !transaction.id.startsWith('demo-'))
    setTransactions(initialTransactions)
    setBudgets(storedBudgets ?? [])
    setSavingsGoal(spendlyStorage.readSavingsGoal() ?? 320)
    spendlyStorage.writeTransactions(initialTransactions)
    setReady(true)

    const syncFromAnotherTab = (event: StorageEvent) => {
      if (event.key === 'spendly_transactions') {
        skipTransactionWrite.current = true
        setTransactions(spendlyStorage.readTransactions() ?? [])
      }
      if (event.key === 'spendly_budgets') {
        skipBudgetWrite.current = true
        setBudgets(spendlyStorage.readBudgets() ?? [])
      }
      if (event.key === 'spendly_savings_goal') {
        skipSavingsGoalWrite.current = true
        setSavingsGoal(spendlyStorage.readSavingsGoal() ?? 320)
      }
    }
    window.addEventListener('storage', syncFromAnotherTab)
    return () => window.removeEventListener('storage', syncFromAnotherTab)
  }, [])

  useEffect(() => {
    if (!ready) return
    if (skipTransactionWrite.current) {
      skipTransactionWrite.current = false
      return
    }
    spendlyStorage.writeTransactions(transactions)
  }, [ready, transactions])
  useEffect(() => {
    if (!ready) return
    if (skipBudgetWrite.current) {
      skipBudgetWrite.current = false
      return
    }
    spendlyStorage.writeBudgets(budgets)
  }, [ready, budgets])
  useEffect(() => {
    if (!ready) return
    if (skipSavingsGoalWrite.current) {
      skipSavingsGoalWrite.current = false
      return
    }
    spendlyStorage.writeSavingsGoal(savingsGoal)
  }, [ready, savingsGoal])

  const saveTransaction = useCallback((transaction: Transaction) => {
    setTransactions(current => {
      const exists = current.some(item => item.id === transaction.id)
      return exists ? current.map(item => item.id === transaction.id ? transaction : item) : [transaction, ...current]
    })
  }, [])
  const deleteTransaction = useCallback((id: string) => {
    setTransactions(current => id === 'all' ? [] : current.filter(item => item.id !== id))
  }, [])
  const saveBudget = useCallback((budget: MonthlyBudget) => {
    setBudgets(current => [budget, ...current.filter(item => item.id !== budget.id && !(item.month === budget.month && item.category === budget.category))])
  }, [])
  const deleteBudget = useCallback((id: string) => {
    setBudgets(current => current.filter(item => item.id !== id))
  }, [])

  return { transactions, budgets, savingsGoal, setSavingsGoal, ready, saveTransaction, deleteTransaction, saveBudget, deleteBudget }
}
