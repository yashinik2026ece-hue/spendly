import { useEffect, useState } from 'react'

export type SharedExpense = { id: string; description: string; amount: number; paidBy: string; participants: string[]; date: string; settled: string[] }
export type SplitGroup = { id: string; name: string; members: string[]; expenses: SharedExpense[] }
export type Subscription = { id: string; name: string; amount: number; cadence: 'weekly' | 'monthly' | 'yearly'; category: string; nextDate: string }
export type SavingsContribution = { id: string; amount: number; date: string; note: string }
export type NoSpendChallenge = { id: string; startDate: string; duration: number; markedDates: string[]; essentialsExcluded: boolean }
export type StudentFinanceData = { groups: SplitGroup[]; subscriptions: Subscription[]; savingsGoal: number; contributions: SavingsContribution[]; challenges: NoSpendChallenge[] }

export const STUDENT_FINANCE_KEY = 'spendly_student_finance_v1'
const EMPTY_DATA: StudentFinanceData = { groups: [], subscriptions: [], savingsGoal: 320, contributions: [], challenges: [] }
const isRecord = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null
const isDate = (value: unknown): value is string => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value
const validStringArray = (value: unknown): value is string[] => Array.isArray(value) && value.every(item => typeof item === 'string')
const isExpense = (value: unknown): value is SharedExpense => isRecord(value) && typeof value.id === 'string' && typeof value.description === 'string' && value.description.trim().length > 0 && typeof value.amount === 'number' && Number.isFinite(value.amount) && value.amount > 0 && typeof value.paidBy === 'string' && validStringArray(value.participants) && value.participants.length > 0 && isDate(value.date) && validStringArray(value.settled)
const isGroup = (value: unknown): value is SplitGroup => isRecord(value) && typeof value.id === 'string' && typeof value.name === 'string' && value.name.trim().length > 0 && validStringArray(value.members) && Array.isArray(value.expenses) && value.expenses.every(isExpense)
const isSubscription = (value: unknown): value is Subscription => isRecord(value) && typeof value.id === 'string' && typeof value.name === 'string' && value.name.trim().length > 0 && typeof value.amount === 'number' && Number.isFinite(value.amount) && value.amount > 0 && ['weekly', 'monthly', 'yearly'].includes(String(value.cadence)) && typeof value.category === 'string' && isDate(value.nextDate)
const isContribution = (value: unknown): value is SavingsContribution => isRecord(value) && typeof value.id === 'string' && typeof value.amount === 'number' && Number.isFinite(value.amount) && value.amount > 0 && isDate(value.date) && typeof value.note === 'string'
const isChallenge = (value: unknown): value is NoSpendChallenge => isRecord(value) && typeof value.id === 'string' && isDate(value.startDate) && typeof value.duration === 'number' && Number.isInteger(value.duration) && value.duration >= 1 && value.duration <= 31 && validStringArray(value.markedDates) && value.markedDates.every(isDate) && typeof value.essentialsExcluded === 'boolean'

export function readStudentFinanceData(): StudentFinanceData {
  if (typeof window === 'undefined') return EMPTY_DATA
  try {
    const raw = window.localStorage.getItem(STUDENT_FINANCE_KEY)
    if (!raw) {
      const legacyGoal = Number(window.localStorage.getItem('spendly_savings_goal'))
      return Number.isFinite(legacyGoal) && legacyGoal > 0 ? { ...EMPTY_DATA, savingsGoal: legacyGoal } : EMPTY_DATA
    }
    const value: unknown = JSON.parse(raw)
    if (!isRecord(value)) return EMPTY_DATA
    return {
      groups: Array.isArray(value.groups) ? value.groups.filter(isGroup) : [],
      subscriptions: Array.isArray(value.subscriptions) ? value.subscriptions.filter(isSubscription) : [],
      savingsGoal: typeof value.savingsGoal === 'number' && Number.isFinite(value.savingsGoal) && value.savingsGoal > 0 ? value.savingsGoal : EMPTY_DATA.savingsGoal,
      contributions: Array.isArray(value.contributions) ? value.contributions.filter(isContribution) : [],
      challenges: Array.isArray(value.challenges) ? value.challenges.filter(isChallenge) : [],
    }
  } catch { return EMPTY_DATA }
}

export function useStudentFinanceData() {
  const [data, setData] = useState<StudentFinanceData>(EMPTY_DATA)
  const [ready, setReady] = useState(false)
  useEffect(() => {
    setData(readStudentFinanceData())
    setReady(true)
    const sync = (event: StorageEvent) => { if (event.key === STUDENT_FINANCE_KEY) setData(readStudentFinanceData()) }
    window.addEventListener('storage', sync)
    return () => window.removeEventListener('storage', sync)
  }, [])
  useEffect(() => {
    if (!ready) return
    try { window.localStorage.setItem(STUDENT_FINANCE_KEY, JSON.stringify(data)) } catch { /* Storage may be disabled or full. */ }
  }, [data, ready])
  return { data, setData, ready }
}

export function localDateString(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

export function upcomingSubscriptionTotal(subscriptions: Subscription[], month: string, today = localDateString()) {
  const [year, monthNumber] = month.split('-').map(Number)
  const monthStart = new Date(year, monthNumber - 1, 1)
  const monthEnd = new Date(year, monthNumber, 0, 23, 59, 59, 999)
  const lowerBound = new Date(`${today}T12:00:00`)
  return subscriptions.reduce((total, subscription) => {
    let due = new Date(`${subscription.nextDate}T12:00:00`)
    let iterations = 0
    while (due < monthStart && iterations < 1200) {
      if (subscription.cadence === 'weekly') {
        due.setDate(due.getDate() + 7)
      } else {
        const step = subscription.cadence === 'yearly' ? 12 : 1
        const targetMonth = due.getMonth() + step
        const targetYear = due.getFullYear() + Math.floor(targetMonth / 12)
        const normalizedMonth = targetMonth % 12
        const originalDay = Number(subscription.nextDate.slice(8, 10))
        due = new Date(targetYear, normalizedMonth, Math.min(originalDay, new Date(targetYear, normalizedMonth + 1, 0).getDate()), 12)
      }
      iterations += 1
    }
    let subscriptionTotal = 0
    while (due <= monthEnd && iterations < 1300) {
      if (due >= monthStart && due >= lowerBound) subscriptionTotal += subscription.amount
      if (subscription.cadence === 'weekly') {
        due.setDate(due.getDate() + 7)
      } else {
        const step = subscription.cadence === 'yearly' ? 12 : 1
        const targetMonth = due.getMonth() + step
        const targetYear = due.getFullYear() + Math.floor(targetMonth / 12)
        const normalizedMonth = targetMonth % 12
        const originalDay = Number(subscription.nextDate.slice(8, 10))
        due = new Date(targetYear, normalizedMonth, Math.min(originalDay, new Date(targetYear, normalizedMonth + 1, 0).getDate()), 12)
      }
      iterations += 1
    }
    return total + subscriptionTotal
  }, 0)
}
