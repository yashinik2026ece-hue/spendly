export const TRANSACTION_CATEGORIES = [
  'Food', 'Travel', 'Education', 'Shopping', 'Entertainment', 'Bills', 'Health', 'Other',
] as const

export type TransactionCategory = (typeof TRANSACTION_CATEGORIES)[number]
export type TransactionType = 'income' | 'expense'

export type Transaction = {
  id: string
  description: string
  amount: number
  type: TransactionType
  category: TransactionCategory
  date: string
  note?: string
}

export type MonthlyBudget = {
  id: string
  month: string
  category: TransactionCategory | 'Overall'
  amount: number
}

export type FinanceTotals = {
  income: number
  expenses: number
  balance: number
  savingsRate: number
}

export type BudgetProgress = {
  budget: MonthlyBudget
  spent: number
  remaining: number
  percentUsed: number
  alert: 50 | 75 | 90 | 100 | null
}
