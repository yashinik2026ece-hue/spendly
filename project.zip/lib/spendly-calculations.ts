import type { BudgetProgress, FinanceTotals, MonthlyBudget, Transaction } from './spendly-types'

export function roundMoney(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100
}

export function monthKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`
}

export function getTransactionsForMonth(transactions: Transaction[], month: string): Transaction[] {
  return transactions.filter(transaction => transaction.date.slice(0, 7) === month)
}

export function calculateTotals(transactions: Transaction[]): FinanceTotals {
  const income = roundMoney(transactions.reduce((total, transaction) => total + (transaction.type === 'income' ? transaction.amount : 0), 0))
  const expenses = roundMoney(transactions.reduce((total, transaction) => total + (transaction.type === 'expense' ? transaction.amount : 0), 0))
  return {
    income,
    expenses,
    balance: roundMoney(income - expenses),
    savingsRate: income > 0 ? Math.max(0, (income - expenses) / income * 100) : 0,
  }
}

export function calculateBudgetProgress(budget: MonthlyBudget, transactions: Transaction[]): BudgetProgress {
  const spent = roundMoney(transactions.reduce((total, transaction) => {
    const matches = transaction.type === 'expense'
      && transaction.date.slice(0, 7) === budget.month
      && (budget.category === 'Overall' || transaction.category === budget.category)
    return total + (matches ? transaction.amount : 0)
  }, 0))
  const percentUsed = spent / budget.amount * 100
  const alert = percentUsed >= 100 ? 100 : percentUsed >= 90 ? 90 : percentUsed >= 75 ? 75 : percentUsed >= 50 ? 50 : null
  return { budget, spent, remaining: roundMoney(budget.amount - spent), percentUsed, alert }
}

export function aggregateMonthlyTotals(transactions: Transaction[], month: string): FinanceTotals {
  return calculateTotals(getTransactionsForMonth(transactions, month))
}

export function sumBudgets(budgets: MonthlyBudget[], month: string): number {
  const monthly = budgets.filter(budget => budget.month === month)
  const overall = monthly.find(budget => budget.category === 'Overall')
  return overall?.amount ?? roundMoney(monthly.reduce((sum, budget) => sum + budget.amount, 0))
}
