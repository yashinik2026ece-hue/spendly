import { describe, expect, it } from 'vitest'
import { calculateSafeToSpend, calculateWellnessScore, compareMonths, findUnusualCategorySpending } from './financial-insights'
import type { Transaction } from './spendly-types'
import { upcomingSubscriptionTotal } from './student-finance'

const row = (id: string, amount: number, type: Transaction['type'], category: Transaction['category'] = 'Food'): Transaction => ({ id, description: id, amount, type, category, date: '2026-11-05' })

describe('transparent financial insight rules', () => {
  it('reserves known bills before calculating safe-to-spend', () => {
    const result = calculateSafeToSpend({ income: 1000, expenses: 400, balance: 600, savingsRate: 60 }, 100, 10)
    expect(result).toEqual({ available: 500, recordedRemainder: 500, perDay: 50 })
    expect(calculateSafeToSpend({ income: 0, expenses: 0, balance: 0, savingsRate: 0 }, 0, 10)).toBeNull()
    expect(calculateSafeToSpend({ income: 100, expenses: 120, balance: -20, savingsRate: 0 }, 5, 10)?.available).toBe(0)
  })

  it('compares expense totals only when prior transactions exist', () => {
    expect(compareMonths([row('this', 150, 'expense')], [row('last', 100, 'expense')])).toEqual({ current: 150, previous: 100, difference: 50, percent: 50 })
    expect(compareMonths([row('this', 150, 'expense')], [])).toEqual({ current: 150, previous: 0, difference: 150, percent: null })
  })

  it('flags only categories that pass both increase thresholds', () => {
    const current = [row('food-now', 160, 'expense'), row('bills-now', 30, 'expense', 'Bills')]
    const previous = [row('food-before', 100, 'expense'), row('bills-before', 25, 'expense', 'Bills')]
    expect(findUnusualCategorySpending(current, previous)).toEqual([{ category: 'Food', current: 160, previous: 100, difference: 60 }])
  })

  it('reserves only upcoming recurring charges in the selected month', () => {
    const subscriptions = [
      { id: 'weekly', name: 'Weekly', amount: 12, cadence: 'weekly' as const, category: 'Other', nextDate: '2026-11-16' },
      { id: 'monthly', name: 'Monthly', amount: 20, cadence: 'monthly' as const, category: 'Other', nextDate: '2026-11-17' },
      { id: 'yearly', name: 'Yearly', amount: 80, cadence: 'yearly' as const, category: 'Other', nextDate: '2026-11-28' },
    ]
    expect(upcomingSubscriptionTotal(subscriptions, '2026-11', '2026-11-18')).toBe(104)
    expect(upcomingSubscriptionTotal(subscriptions, '2026-12', '2026-11-18')).toBe(68)
  })

  it('does not manufacture a wellness score without both income and expense history', () => {
    expect(calculateWellnessScore([row('expense', 30, 'expense')], [], 0)).toBeNull()
    expect(calculateWellnessScore([row('income', 500, 'income')], [], 0)).toBeNull()
  })

  it('scores recorded income and spending with explicit missing-data exclusions', () => {
    const score = calculateWellnessScore([row('income', 500, 'income'), row('expense', 200, 'expense')], [], 0)
    expect(score).toEqual({ score: 92, net: 30, savings: 25, budget: null, comparison: null, coverage: 5 })
  })
})
