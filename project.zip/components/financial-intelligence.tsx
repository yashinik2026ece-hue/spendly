'use client'

import { useMemo, useState, type FormEvent } from 'react'
import { Lightbulb, ShieldCheck, Sparkles, TrendingDown, TrendingUp } from 'lucide-react'
import { calculateTotals, getTransactionsForMonth, monthKey, roundMoney, sumBudgets } from '@/lib/spendly-calculations'
import { calculateSafeToSpend, calculateWellnessScore, compareMonths, findUnusualCategorySpending } from '@/lib/financial-insights'
import type { MonthlyBudget, Transaction } from '@/lib/spendly-types'
import { upcomingSubscriptionTotal, type Subscription } from '@/lib/student-finance'

type Props = { transactions: Transaction[]; budgets: MonthlyBudget[]; subscriptions: Subscription[]; month: string }
const money = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value)
const previousMonth = (month: string) => { const date = new Date(`${month}-01T12:00:00`); date.setMonth(date.getMonth() - 1); return monthKey(date) }
const categoryTotals = (items: Transaction[]) => items.reduce<Record<string, number>>((totals, item) => { if (item.type === 'expense') totals[item.category] = roundMoney((totals[item.category] ?? 0) + item.amount); return totals }, {})

export function FinancialIntelligence({ transactions, budgets, subscriptions, month }: Props) {
  const [buyName, setBuyName] = useState('')
  const [buyAmount, setBuyAmount] = useState('')
  const [buyCategory, setBuyCategory] = useState('')
  const [purchaseResult, setPurchaseResult] = useState<{ affordable: boolean; explanation: string } | null>(null)
  const currentItems = useMemo(() => getTransactionsForMonth(transactions, month), [transactions, month])
  const previous = previousMonth(month)
  const previousItems = useMemo(() => getTransactionsForMonth(transactions, previous), [transactions, previous])
  const current = calculateTotals(currentItems)
  const monthDays = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate()
  const daysRemaining = Math.max(1, month === monthKey(new Date()) ? monthDays - new Date().getDate() + 1 : monthDays)
  const futureSubscriptionReserve = upcomingSubscriptionTotal(subscriptions, month)
  const safeToSpend = calculateSafeToSpend(current, futureSubscriptionReserve, daysRemaining)
  const remainingRecordedFunds = current.income - current.expenses - futureSubscriptionReserve
  const monthBudget = sumBudgets(budgets, month)
  const categoryCurrent = categoryTotals(currentItems)
  const topCategory = Object.entries(categoryCurrent).sort((a, b) => b[1] - a[1])[0]
  const comparison = compareMonths(currentItems, previousItems)
  const alerts = findUnusualCategorySpending(currentItems, previousItems)
  const wellness = calculateWellnessScore(currentItems, previousItems, monthBudget)
  const topCategoryShare = topCategory && current.expenses > 0 ? topCategory[1] / current.expenses : 0
  const personality = topCategory ? topCategoryShare >= 0.5 ? `${topCategory[0]}-focused spending pattern` : 'Spending is spread across categories' : ''
  const runPurchaseCheck = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const amount = Number(buyAmount)
    if (!buyName.trim() || !Number.isFinite(amount) || amount <= 0) { setPurchaseResult({ affordable: false, explanation: 'Enter a name and a purchase amount greater than zero.' }); return }
    const categoryBudget = budgets.find(item => item.month === month && item.category === buyCategory)?.amount
    const overallBudget = budgets.find(item => item.month === month && item.category === 'Overall')?.amount
    const currentCategorySpend = categoryCurrent[buyCategory] ?? 0
    const uncommittedBudget = categoryBudget === undefined ? null : roundMoney(categoryBudget - currentCategorySpend)
    const uncommittedOverall = overallBudget === undefined ? null : roundMoney(overallBudget - current.expenses)
    const covers = remainingRecordedFunds >= amount
    const staysWithinBudget = (uncommittedBudget === null || amount <= uncommittedBudget) && (uncommittedOverall === null || amount <= uncommittedOverall)
    const affordable = covers && staysWithinBudget
    const budgetExplanation = [
      overallBudget === undefined ? 'No overall budget is set.' : `Overall budget has ${money(uncommittedOverall ?? 0)} remaining (${money(overallBudget)} minus ${money(current.expenses)} recorded expenses).`,
      categoryBudget === undefined ? (buyCategory ? `No ${buyCategory} category budget is set.` : 'No category was selected, so no category-specific limit was applied.') : `${buyCategory} budget has ${money(uncommittedBudget ?? 0)} remaining (${money(categoryBudget)} budget minus ${money(currentCategorySpend)} recorded spending).`,
    ].join(' ')
    setPurchaseResult({ affordable, explanation: `Recorded income ${money(current.income)} − recorded expenses ${money(current.expenses)} − known upcoming subscriptions ${money(futureSubscriptionReserve)} = ${money(remainingRecordedFunds)} available before this purchase. ${budgetExplanation} ${affordable ? 'The amount fits these recorded values.' : 'This purchase exceeds at least one recorded limit.'}` })
  }
  return <div className="feature-stack"><header className="feature-heading"><span className="feature-icon"><Lightbulb /></span><div><h2>Smart Financial Intelligence</h2><p>Rule-based observations from your saved transactions and budgets—not forecasts or random analytics.</p></div></header><div className="intelligence-grid">
    <article className="panel intelligence-card"><span className="safe-icon"><ShieldCheck /></span><h3>Safe to spend</h3>{safeToSpend ? <><strong>{money(safeToSpend.available)}</strong><p>Recorded income minus expenses and upcoming subscriptions due in {month}.</p><div className="intelligence-note">About {money(safeToSpend.perDay)} per day across {daysRemaining} remaining days. {safeToSpend.recordedRemainder < 0 ? `Recorded spending and subscription reserve exceed income by ${money(Math.abs(safeToSpend.recordedRemainder))}.` : 'This is based only on what you have entered; unrecorded bills are not included.'}</div></> : <p className="feature-empty">Add income transactions for {month} to calculate this indicator.</p>}</article>
    <article className="panel intelligence-card"><span className="safe-icon"><Sparkles /></span><h3>Spending personality</h3>{topCategory ? <><strong>{personality}</strong><p>{money(topCategory[1])} of {money(current.expenses)} recorded expenses ({current.expenses ? Math.round(topCategory[1] / current.expenses * 100) : 0}%).</p><div className="intelligence-note">Rule: a category is called the focus when it represents at least 50% of recorded expenses in {month}. This is a description, not a judgment.</div></> : <p className="feature-empty">No expense transactions recorded for {month}.</p>}</article>
    <article className="panel intelligence-card"><span className="safe-icon">{comparison.difference <= 0 ? <TrendingDown /> : <TrendingUp />}</span><h3>Month-to-month comparison</h3>{previousItems.length ? <><strong>{comparison.percent === null ? `${money(comparison.current)} vs. ${money(comparison.previous)}` : `${comparison.difference > 0 ? '+' : ''}${comparison.percent}% spending`}</strong><p>{money(comparison.current)} in {month} compared with {money(comparison.previous)} in {previous}.</p><div className="intelligence-note">Difference: {comparison.difference > 0 ? 'more' : comparison.difference < 0 ? 'less' : 'the same'} by {money(Math.abs(comparison.difference))}, using recorded expenses only.</div></> : <p className="feature-empty">Add transaction records for {previous} and {month} to compare months.</p>}</article>
    <article className="panel intelligence-card"><span className="safe-icon"><TrendingUp /></span><h3>Unusual spending alerts</h3>{alerts.length ? alerts.map(alert => <div className="alert-detail" key={alert.category}><b>{alert.category} is up {money(alert.difference)}</b><p>{money(alert.current)} this month versus {money(alert.previous)} last month (at least 50% and $10 higher).</p></div>) : <p className="feature-empty">{previousItems.length ? 'No category met the alert rule: at least 50% and $10 above last month.' : 'Add transactions for two months to check category changes.'}</p>}</article>
    <article className="panel intelligence-card wellness-card"><span className="safe-icon"><ShieldCheck /></span><h3>Financial wellness score</h3>{wellness ? <><strong>{wellness.score}<small> / 100</small></strong><p>Transparent rule score for {month}; not a credit score or professional assessment. Weighted points normalize to 100; unavailable comparisons or budgets are excluded.</p><ul className="score-breakdown"><li>Positive monthly net: {wellness.net}/30</li><li>Savings rate (capped at 20%): {wellness.savings}/25</li><li>{wellness.budget !== null ? `Budget use: ${wellness.budget}/20` : 'Budget: not set (excluded)'}</li><li>{wellness.comparison !== null ? `Compared with last month: ${wellness.comparison}/15` : 'Comparison: unavailable (excluded)'}</li><li>{`Transaction coverage: ${wellness.coverage}/10`}</li></ul></> : <p className="feature-empty">Record both income and expense transactions in {month}. No score is produced from sample data.</p>}</article>
    <article className="panel intelligence-card purchase-card"><span className="safe-icon"><Lightbulb /></span><h3>Before you buy</h3><p>Check a possible purchase against recorded monthly funds and any overall or category budget you have set.</p><form className="feature-form" onSubmit={runPurchaseCheck}><label>What are you considering?<input required maxLength={80} value={buyName} onChange={event => setBuyName(event.target.value)} /></label><div className="form-pair"><label>Amount<input required min="0.01" step="0.01" type="number" value={buyAmount} onChange={event => setBuyAmount(event.target.value)} /></label><label>Category<select value={buyCategory} onChange={event => setBuyCategory(event.target.value)}><option value="">No category budget</option>{[...new Set(budgets.map(item => item.category).filter(item => item !== 'Overall'))].map(item => <option key={item}>{item}</option>)}</select></label></div><button className="primary-btn">Check this purchase</button></form>{purchaseResult && <div className={`intelligence-note ${purchaseResult.affordable ? 'positive-note' : 'warning-note'}`} role="status"><b>{purchaseResult.affordable ? 'Looks within your recorded limits' : 'Pause and review the numbers'}</b><p>{purchaseResult.explanation}</p></div>}</article>
  </div></div>
}
