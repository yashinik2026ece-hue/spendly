'use client'

import { useMemo, useState, type FormEvent } from 'react'
import { Pencil, Plus, Trash2, X } from 'lucide-react'
import { calculateBudgetProgress } from '@/lib/spendly-calculations'
import { TRANSACTION_CATEGORIES, type MonthlyBudget, type Transaction } from '@/lib/spendly-types'

const currency = (value: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value)

export function BudgetManager({ month, budgets, transactions, onSave, onDelete }: {
  month: string
  budgets: MonthlyBudget[]
  transactions: Transaction[]
  onSave: (budget: MonthlyBudget) => void
  onDelete: (id: string) => void
}) {
  const [editing, setEditing] = useState<MonthlyBudget | null>(null)
  const [category, setCategory] = useState<MonthlyBudget['category']>('Overall')
  const [amount, setAmount] = useState('')
  const [error, setError] = useState('')
  const monthBudgets = useMemo(() => budgets.filter(budget => budget.month === month), [budgets, month])
  const overall = monthBudgets.find(budget => budget.category === 'Overall')
  const progress = monthBudgets.map(budget => calculateBudgetProgress(budget, transactions))

  const startEdit = (budget?: MonthlyBudget) => {
    setEditing(budget ?? { id: '', month, category: 'Overall', amount: 0 })
    setCategory(budget?.category ?? 'Overall')
    setAmount(budget ? String(budget.amount) : '')
    setError('')
  }

  const save = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const value = Number(amount)
    if (!Number.isFinite(value) || value <= 0) {
      setError('Enter a budget amount greater than zero.')
      return
    }
    const existing = monthBudgets.find(budget => budget.category === category)
    onSave({ id: editing?.id || existing?.id || crypto.randomUUID(), month, category, amount: value })
    setEditing(null)
  }

  return <div className="secondary-grid">
    <section className="panel full-panel">
      <div className="panel-heading"><div><h2>{new Date(`${month}-01T12:00:00`).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} overview</h2><p>Set spending limits that work for you</p></div><button className="outline-btn" onClick={() => startEdit()}><Plus size={15}/> Add budget</button></div>
      {overall ? <>
        <div className="budget-big">{currency(calculateBudgetProgress(overall, transactions).spent)} <span>of {currency(overall.amount)}</span></div>
        <div className="bar-track large"><i style={{ width: `${Math.min(100, calculateBudgetProgress(overall, transactions).percentUsed)}%` }}/></div>
        <div className="budget-foot wide"><span>{Math.round(calculateBudgetProgress(overall, transactions).percentUsed)}% used</span><b>{currency(calculateBudgetProgress(overall, transactions).remaining)} remaining</b></div>
      </> : <div className="budget-empty"><b>No overall limit yet</b><span>Set an overall budget or start with category budgets.</span></div>}
      {progress.map(({ budget, spent, remaining, percentUsed, alert }) => <div className="budget-category" key={budget.id}>
        <div><b>{budget.category === 'Overall' ? 'Overall budget' : budget.category}</b><span>{currency(spent)} <small>/ {currency(budget.amount)}</small></span></div>
        <div className="bar-track"><i className={alert && alert >= 90 ? 'budget-alert' : ''} style={{ width: `${Math.min(100, percentUsed)}%` }}/></div>
        <div className="budget-row-bottom"><small className="threshold">{Math.round(percentUsed)}% used · {currency(remaining)} remaining{alert ? ` · ${alert}% alert` : ''}</small><span><button className="budget-action" aria-label={`Edit ${budget.category} budget`} onClick={() => startEdit(budget)}><Pencil size={13}/></button><button className="budget-action delete-budget" aria-label={`Delete ${budget.category} budget`} onClick={() => onDelete(budget.id)}><Trash2 size={13}/></button></span></div>
      </div>)}
      {!monthBudgets.length && <p className="budget-intro">Create an overall monthly limit, or add individual category limits to track what matters most.</p>}
    </section>
    <section className="panel side-panel"><span className="safe-icon">%</span><h2 className="side-title">Budget check-ins</h2><p>Progress alerts appear at 50%, 75%, 90%, and 100% of each limit. Category budgets track only matching expenses for this month.</p><div className="safe-note">Budget remaining may be negative when spending exceeds your limit.</div></section>
    {editing && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setEditing(null) }}><form className="transaction-modal" role="dialog" aria-modal="true" aria-labelledby="budget-dialog-title" onSubmit={save}>
      <div className="modal-head"><div><span className="modal-kicker">MONTHLY PLAN</span><h2 id="budget-dialog-title">{editing.id ? 'Edit budget' : 'Add a budget'}</h2></div><button type="button" className="icon-btn" aria-label="Close" onClick={() => setEditing(null)}><X size={18}/></button></div>
      <label>Budget type<select value={category} onChange={event => setCategory(event.target.value as MonthlyBudget['category'])}><option value="Overall">Overall</option>{TRANSACTION_CATEGORIES.map(item => <option key={item} value={item}>{item}</option>)}</select></label>
      <label>Monthly limit<input type="number" min="0.01" step="0.01" required autoFocus value={amount} onChange={event => setAmount(event.target.value)} placeholder="e.g. 300"/></label>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button type="submit" className="primary-btn submit-btn"><Plus size={16}/>{editing.id ? 'Save budget' : 'Create budget'}</button>
    </form></div>}
  </div>
}
